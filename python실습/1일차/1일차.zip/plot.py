import matplotlib.pyplot as plt

plt.plot([1, 3, 5, 2, 8])
plt.show()
