f = open("새파일.txt", 'w')

f.close()