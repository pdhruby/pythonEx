print(all([1, 2, abs(-3)-3]))  # False

print(chr(ord('a')) == 'a')   # True

