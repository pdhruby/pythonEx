# lambda : 익명 함수(이름이 없는 함수 지정)
add = lambda a, b : a + b

print(add(4, 6))


