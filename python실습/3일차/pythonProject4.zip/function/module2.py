# 별도의 파일로 자주 사용하는 함수나 클랫를 만들어 놓는다.
def mul(a, b):
    return a * b


def div(a, b):
    return a / b