def wave_test():
    print("wave")